package MobileApp;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v110.log.Log;
import org.openqa.selenium.interactions.Actions;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

/**
 * Unit test for simple App.
 */
public class Basic 
{
	AndroidDriver driver;
	Actions action;
	String LoginPage="//*[@content-desc='Welcome and Login']";
	String EmailID="//android.widget.EditText[@content-desc='EmailID']";
	String Password="//android.widget.EditText[@content-desc='Password']";
	String LoginButton="//android.widget.Button[@content-desc='Login']";
	String LoginSuccessmsg="//*[@content-desc='Success msg']";
	String Popup="//*[@content-desc='Popup Error']";
	String Retrybutton="//*[@content-desc='OK']";
	String OKbutton="//*[@content-desc='OK']";
	String ForgotPasswordLink="//*[@content-desc='Forgot Password?']";
	String ForgotPasswordPage="//*[@content-desc='Forgot Password']";
	String RecoverButton="//*[@content-desc='Recover']";
	String Successmsg="//android.view.View[1]";
	String GmailSignIn="SignIn";
	String GmailEmail="email_id";
	String GmailPass="passwrd";
	String GmailLogin="//*[text()='login']";
	String ResetMail="//*[@class=E-mail'][1]";
	String NewPassword="New_Password";
	String ReenterPassword="Re_Password";
	String PasswordStrength="//*[@id='New_Password']//following-sibling::android.view.view[2]";
	String ConfirmButton="set_password";
	
	
	public void launch() throws MalformedURLException, InterruptedException
	{
		//Code to Start Server
		AppiumDriverLocalService appium= new AppiumServiceBuilder().withAppiumJS(new File("C://Users//Shailesh Vishwakarma//AppData//Roaming//npm//node_modules//appium//lib//main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).build();
		
		//appium.start();
		/* Method 2*/
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("pixel6a");
		options.setApp("C://Users//Shailesh Vishwakarma//Downloads//IMP//TCAPPS//App_5.apk");
		options.setCapability("testdroid_testTimeout", 10000);
		options.getPlatformName();
		driver= new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"),   options);
		action=new Actions(driver);
		//TouchAction t =new TouchAction(driver);
		//Att=new AppiumDriver(options);
		
	}
	
	public void LoginEmail() throws MalformedURLException, InterruptedException
	{
		
		driver.findElement(By.xpath(LoginPage));
		//EmailID
		Thread.sleep(1000);
		driver.findElement(By.xpath(EmailID)).sendKeys("sv7330@gmail.in");
		
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(Password)).sendKeys("Password@1");
		
		Thread.sleep(2000);
		Boolean status=driver.findElement(By.xpath(LoginButton)).isEnabled();
		if(status)
		{
			System.out.println("Login Button is Enabled");
			assertTrue( true );
		}else
		{
			assertTrue( false );
		}
		driver.findElement(By.xpath(LoginButton)).click();
		Thread.sleep(8000);
		
		
		Thread.sleep(10000);
		String msg=driver.findElement(By.xpath(LoginSuccessmsg)).getText();
		
		if(msg.equalsIgnoreCase("Successfully Login"))
		{
			assertTrue( true );
		}else
		{
			assertTrue( false );
		}
	}
	
	public void VerifyInvalidUser() throws MalformedURLException, InterruptedException
	{
		//Invalid EmailID 
		Thread.sleep(10000);
		driver.findElement(By.xpath(EmailID)).sendKeys("empty@gmail.com");
		
		//Invalid Password
		Thread.sleep(5000);
		driver.findElement(By.xpath(Password)).sendKeys("45665855");
	    Thread.sleep(7000);
	    
		String Popupmsg=driver.findElement(By.xpath(Popup)).getText();
		
		if(Popupmsg.equalsIgnoreCase("Invalid Email") || Popupmsg.equalsIgnoreCase("Invalid Password"))
		{
			System.out.println(Popupmsg+" message is displayed");
			assertTrue( true );
		}else
		{
			assertTrue( false );
		}
	}
	
	public void RetryLogin() throws MalformedURLException, InterruptedException
	{
		//Invalid EmailID 
		Thread.sleep(10000);
		driver.findElement(By.xpath(EmailID)).sendKeys("empty@gmail.com");
		
		//Invalid Password
		Thread.sleep(5000);
		driver.findElement(By.xpath(Password)).sendKeys("45665855");
	    Thread.sleep(7000);
	    
		Boolean Popupmsg=driver.findElement(By.xpath(Popup)).isDisplayed();
		if(Popupmsg)
		{
			assertTrue( true );
		}
		driver.findElement(By.xpath(Retrybutton)).isDisplayed();
		
		Boolean Email=driver.findElement(By.xpath(EmailID)).isDisplayed();
		Boolean Pass=driver.findElement(By.xpath(Password)).isDisplayed();
		if(Email==true && Pass==true)
		{
			System.out.println("Login Page");
			assertTrue( true );
		}
	}
	
	public void LoginButonDisable() throws MalformedURLException, InterruptedException
	{
		Thread.sleep(10000);
		driver.findElement(By.xpath(EmailID)).sendKeys("");
		
		//Invalid Password
		Thread.sleep(5000);
		driver.findElement(By.xpath(Password)).sendKeys("");
	    Thread.sleep(7000);
		Thread.sleep(2000);
		Boolean status=driver.findElement(By.xpath(LoginButton)).isEnabled();
		if(!status)
		{
			System.out.println("Login Button is Disabled");
			assertTrue( true );
		}else
		{
			System.out.println("Login Button is not Disabled");
			assertTrue( false );
		}
	}
	
	
	
	public void VerifyForgetPasswordPage() throws MalformedURLException, InterruptedException
	{
		Thread.sleep(4000);
		driver.findElement(By.xpath(ForgotPasswordLink)).click();
		Thread.sleep(7000);
		
		String Page=driver.findElement(By.xpath(ForgotPasswordPage)).getText();
		Thread.sleep(2000);
		if(Page.equalsIgnoreCase("Forgot Password"))
		{
			System.out.println(Page+" Page Displayed");
			assertTrue( true );
		}else
		{
			System.out.println("Page Not Displayed");
			assertTrue( false );
		}
	}
	
	public void ForgetPassword() throws Throwable
	{
		Thread.sleep(4000);
		driver.findElement(By.xpath(ForgotPasswordLink)).click();
		Thread.sleep(7000);
		
		driver.findElement(By.xpath(EmailID)).sendKeys("sv7330@gmail.com");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(RecoverButton));
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(Successmsg)).isDisplayed();
		driver.findElement(By.xpath(OKbutton)).click();
		
		//Launch Chromebrowser
		//??????
		launchChrome();
		driver.get("https://www.gmail.com");
		Thread.sleep(9000);
		
		driver.findElement(By.id(GmailSignIn)).click();
		Thread.sleep(7000);
		
		driver.findElement(By.id(GmailEmail)).sendKeys("sv7330@gmail.com");
		driver.findElement(By.id(GmailPass)).sendKeys("0000000");
		
		driver.findElement(By.id(GmailLogin)).click();
		Thread.sleep(6000);
		
		List<WebElement> newmail=driver.findElements(By.xpath(ResetMail));
		int i=0;
		for (WebElement temp:newmail)
		{
			String value=temp.getAttribute("view");
			String text=temp.getText(); 
		
		if(value.equalsIgnoreCase("1") && text.contains("reset"))
		{
			temp.click();
			Thread.sleep(5000);
			driver.findElement(By.linkText("here")).click();
		}
		}
		String value1=driver.findElement(By.xpath("")).getText();
		if(value1.equalsIgnoreCase("Reset Password"))
		{
			driver.findElement(By.id(NewPassword)).sendKeys("Password@1");
			//Check Password Strength
			String strength=driver.findElement(By.xpath(PasswordStrength)).getText();
			if(!strength.equals(null))
			{
				System.out.println("Password is "+strength);
			}
			
			driver.findElement(By.id(ReenterPassword)).sendKeys("Password@1");
			Thread.sleep(2000);
			driver.findElement(By.id(ConfirmButton)).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath(LoginSuccessmsg));
			driver.findElement(By.xpath(OKbutton)).click();
			Thread.sleep(8000);
			driver.findElement(By.xpath(LoginPage));
			
			//LOGIN AGAIN
			launch();
			Thread.sleep(1000);
			driver.findElement(By.xpath(EmailID)).sendKeys("sv7330@gmail.in");
			
			
			Thread.sleep(1000);
			driver.findElement(By.xpath(Password)).sendKeys("Password@1");
			
			Thread.sleep(2000);
			driver.findElement(By.xpath(LoginButton)).isEnabled();

			driver.findElement(By.xpath(LoginButton)).click();
			Thread.sleep(8000);
			
			
			Thread.sleep(10000);
			String msg=driver.findElement(By.xpath(LoginSuccessmsg)).getText();
			
			if(msg.equalsIgnoreCase("Successfully Login"))
			{
				assertTrue( true );
			}else
			{
				assertTrue( false );
			}
		}
		
		
	}
	
	public void launchChrome() throws MalformedURLException, InterruptedException
	{
		//Code to Start Server
		//AppiumDriverLocalService appium= new AppiumServiceBuilder().withAppiumJS(new File("C://Users//Shailesh Vishwakarma//AppData//Roaming//npm//node_modules//appium//lib//main.js"))
		//		.withIPAddress("127.0.0.1").usingPort(4723).build();
		
		//appium.start();
		/* Method 2*/
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("pixel6a");
		options.setChromedriverExecutable("C://Users//Shailesh Vishwakarma//Downloads//IMP//chromedriver 120");
		options.setCapability("browserName", "Chrome");
		options.getPlatformName();
		driver= new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"),   options);
		action=new Actions(driver);
		//TouchAction t =new TouchAction(driver);
		//Att=new AppiumDriver(options);
		
	}
	
	
	

	
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
