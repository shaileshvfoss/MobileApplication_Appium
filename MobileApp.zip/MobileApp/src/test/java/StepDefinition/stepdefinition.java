package StepDefinition;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import MobileApp.Basic;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.en.*;
public class stepdefinition extends Basic {
	
	Basic BS = new Basic();
	
	@Given("^Application Launched$")
	public void application_launched() throws Throwable {
	BS.launch();
	}
	
	@And("^Login into App with Valid Credentials$")
	public void valid_Login() throws Throwable {
		BS.LoginEmail();
	}
	
	@And("^Verify Invalid Credentials$")
	public void Invalid_Login() throws Throwable {
		BS.VerifyInvalidUser();
	}
	
	@And("^Verify Login Button Disabled$")
	public void Login_Disabled() throws Throwable, InterruptedException {
		BS.LoginButonDisable();
	}
	
	@And("^Verify Forgot Password Page$")
	public void Forgot_PasswordPage() throws Throwable {
		BS.VerifyForgetPasswordPage();
	}
	
	@And("^Verify Login Page after Login Failure$")
	public void Login_Verify()  throws Throwable {
		BS.RetryLogin();
	}
	
	@And("^Proccess Forgot Password Page$")
	public void Forgot_password_process() throws Throwable {
		BS.ForgetPassword();
	}
	
	
}
